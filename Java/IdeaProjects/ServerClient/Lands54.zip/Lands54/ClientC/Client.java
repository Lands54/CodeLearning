package com.Lands54.ClientC;

import static java.lang.Thread.sleep;

public class Client {
    static User user;
    static ClientDecoder clientDecoder;

    public static User open(int port){
        Client.user = new User();
        Client.clientDecoder = new ClientDecoder(port);
        return user;
    }



}
