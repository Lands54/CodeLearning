package com.Lands54.ClientC;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

class ClientDecoder {
        SocketChannel serverChannel;
        InetSocketAddress serverAddress;
        ByteBuffer byteBuffer = ByteBuffer.allocate(2048);
        Selector listener;
        public ClientDecoder(int port){
            this.serverAddress = new InetSocketAddress(port);
            try {
                this.listener = Selector.open();
                connect(true);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        public String[] commandHandle(String method, String body) {
            try {
                this.send(method, body);
                return this.receive().split("@");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        public boolean connect(boolean n) throws IOException {
            this.serverChannel = SocketChannel.open();
            this.serverChannel.configureBlocking(false);
            boolean temp = this.serverChannel.connect(this.serverAddress);
            while (!this.serverChannel.finishConnect()) ;
            if (this.serverChannel.finishConnect()) {
                System.out.println("Connection built");
            } else {
                System.out.println("Connection failed");
            }

            this.serverChannel.register(listener, SelectionKey.OP_WRITE);
            return temp;
        }

        private String commandBuild(String method, String body){
            StringBuilder stringBuilder = new StringBuilder(Client.user.accountID);
            stringBuilder.append("@");
            stringBuilder.append(method);
            stringBuilder.append("@");
            stringBuilder.append(body);
            return stringBuilder.toString();
        }

        public void send(String method, String body) throws IOException {
            String command = commandBuild(method, body);
            listener.select(1000);
            Set<SelectionKey> selectionKeys = listener.selectedKeys();
            Iterator<SelectionKey> iterator = selectionKeys.iterator();
            while(iterator.hasNext()) {
                SelectionKey selectionKey = iterator.next();
                if (selectionKey.isWritable()) {
                    this.serverChannel.write(ByteBuffer.wrap(command.getBytes()));
                    selectionKey.interestOps(SelectionKey.OP_READ);
                }
            }
        }

        public String receive() throws IOException {
            listener.select(1000);
            StringBuilder stringBuilder = new StringBuilder();
            Set<SelectionKey> selectionKeys = listener.selectedKeys();
            Iterator<SelectionKey> iterator = selectionKeys.iterator();
            while(iterator.hasNext()){
                SelectionKey selectionKey = iterator.next();
                byteBuffer.clear();
                this.serverChannel.read(this.byteBuffer);
                this.byteBuffer.flip();
                while(byteBuffer.hasRemaining())
                    stringBuilder.append((char) this.byteBuffer.get());
                selectionKey.interestOps(SelectionKey.OP_READ);
            }
            System.out.println(stringBuilder.toString());
            return stringBuilder.toString();
        }
    }