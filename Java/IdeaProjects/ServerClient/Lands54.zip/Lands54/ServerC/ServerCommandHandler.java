package com.Lands54.ServerC;

import static java.lang.Thread.sleep;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.Hashtable;

public class ServerCommandHandler implements Runnable{
    static Hashtable<String, Object> accountTable = new Hashtable<>();
    Server server;
    Boolean shouldStop = false;

    ServerCommandHandler(Server server){
        this.server = server;
    }
    @Override
    public void run() {
        while (!this.shouldStop){
            String ir = server.getCommand();
            try {
                commandHandle(ir);
            } catch (NullPointerException e){
                try {
                    sleep(100);
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
            }
        }
    }

    // Command ::= ID@Method@$0@$1@$2+
    // SocketChannel built
    // SocketChannel --send-> Login@Client.User@Password
    // Login --pass-> new Server.Server.Person(Client.User, Password)
    // Bundle<SocketChannel, Server.Server.Person> --Socket.Request-> equal(MessageID, PersonID) -> Server.Server.Person
    // -> Server.Server.Person.Method(Attributes) {-> WriteBuffer<ID@DATA> -> equal(MessageID, PersonID) -> Socket.Register(OP_WRITE)}
    // Socket.write(WriteBuffer)
    public void commandHandle(String command) {
        String[] runnableCommand = command.split("@");
        String[] args = new String[runnableCommand.length - 2];
        Class identity;
        for (int i = 2; i < runnableCommand.length; i++) {
            args[i - 2] = runnableCommand[i];
        }
        //reflect
        try {
            if (runnableCommand[1].equals("login") | runnableCommand[1].equals("register")){
                Method method = Class.forName("com.Lands54.ServerC.Person").getMethod(runnableCommand[1], String.class, String.class);
                Class user = Class.forName("com.Lands54.ServerC.Person");
                method.invoke(user, args);
            } else {
                String accountId = runnableCommand[0];
                String methodName = runnableCommand[1];
                Person requester = (Person) accountTable.get(accountId);
                if (!requester.identity.equals("Server.Server.Asker")&!requester.identity.equals("Server.Teacher")){
                    identity = Class.forName("com.Lands54.ServerC.Swimer");
                } else {
                    identity = Class.forName(requester.identity);
                }
                Method[] methods = identity.getMethods();
                for (Method method : identity.getMethods()){
                    if (method.getName().equals(methodName)){
                        method.invoke(requester, args);
                        return;
                    }
                }
                server.putMessage(runnableCommand[0], runnableCommand[1], "errorMethod");
            }
        } catch (Exception e) {
            e.printStackTrace();
            server.putMessage(runnableCommand[0], runnableCommand[1], "errorArgs");
        }
    }

    public void close(){
        this.shouldStop = !this.shouldStop;
    }

    public static void main(String[] args) throws IOException, SQLException, InterruptedException {
        Person.server = new Server(9999);
        Person.personSQL = new PersonSQL();
        Person.personSQL.createDB("ASK");
        Person.personSQL.setStmt();
        Person.server.serverManage();
    }
}
