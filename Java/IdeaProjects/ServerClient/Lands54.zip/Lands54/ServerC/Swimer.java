package com.Lands54.ServerC;

public class Swimer extends Person {
    //can be objected Server.Server.Person
}
