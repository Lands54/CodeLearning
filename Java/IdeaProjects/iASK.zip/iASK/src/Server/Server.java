package Server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import static java.lang.System.*;
import static java.lang.Thread.sleep;

public class Server {
    ConcurrentHashMap<String, SocketChannel> loginBuffer = new ConcurrentHashMap<>();
    ConcurrentHashMap<String, SocketChannel> SocketchannelMap = new ConcurrentHashMap<>();
    private ConcurrentLinkedQueue<String> commendBuffer = new ConcurrentLinkedQueue<>();
    private ConcurrentLinkedQueue<String> sendBuffer = new ConcurrentLinkedQueue<>();
    ArrayList<SocketChannel> connectedList = new ArrayList<>();
    private Selector listener = Selector.open();

    public Server(int port) throws IOException {
        ServerSocketChannel server = ServerSocketChannel.open();
        server.bind(new InetSocketAddress(port));
        server.configureBlocking(false);
        SelectionKey key = server.register(listener, SelectionKey.OP_ACCEPT);
        out.println("Server.Server has been built");
    }

    public String getCommand() {
        return this.commendBuffer.poll();
    }

    public void putMessage(String message0, String message1, String message2) {
        this.sendBuffer.add(message0 + "@" + message1 + "@" + message2);
    }

    private int numberOfSocketChannel() {
        Set<SelectionKey> keySet = listener.keys();
        Iterator<SelectionKey> keyIterator = keySet.iterator();
        HashSet<SocketChannel> socketChannelSet = new HashSet<SocketChannel>();
        return loginBuffer.size() + SocketchannelMap.size();
    }

    private void showCommandBuffer() {
        for (String command :
                this.commendBuffer) {
            out.println("|" + command + "|");
        }
    }

    public void serverManage() throws IOException, InterruptedException {
        ServerCommandHandler serverCommandHandler = new ServerCommandHandler(this);
        Thread handler = new Thread(serverCommandHandler);
        handler.start();
        SelectionKey key = null;
        int i = 0;
        while (true) {
            try {
                listener.select(5000);
                Set<SelectionKey> keySet = listener.selectedKeys();
                Iterator<SelectionKey> keyIterator = keySet.iterator();
                while (keyIterator.hasNext()) {
                    key = keyIterator.next();
                    keyIterator.remove();
                    opDetectServer(key);
                }
                out.println("Number of Connection is " + numberOfSocketChannel() + ":" + i++);
            } catch (IOException e) {
                key.channel().close();
                key.cancel();
                out.println("Error Connection, Server.Server has closed it");
            } catch (NullPointerException e) {
                sleep(100);
            } catch (Exception e){
                key.channel().close();
                key.cancel();
                e.printStackTrace();
                out.println("Unknown Error, Server.Server has closed it");
            }

        }
    }

    private void opDetectServer(SelectionKey key) throws IOException, NullPointerException {
        StringBuffer stringBuffer = new StringBuffer();
        ByteBuffer byteBuffer = ByteBuffer.allocate(128);
        SelectableChannel tempServer = key.channel();
        switch (keyToInt(key)) {
            case 0:
                ServerSocketChannel server = (ServerSocketChannel)tempServer;
                out.println("Receive a connection, try to accept");
                SocketChannel client = server.accept();
                out.println("Connecting");
                while (!client.isConnected()) ;
                if (client.finishConnect()) {
                    out.println("Connection Successfully");
                    client.configureBlocking(false);
                    client.register(listener, SelectionKey.OP_READ);
                }
                break;

            case 1:
                ((ServerSocketChannel) tempServer).register(listener, SelectionKey.OP_READ);
                break;

            case 2://commend_read_decision and ready for write
                client = (SocketChannel) tempServer;
                client.configureBlocking(false);
                client.read(byteBuffer);
                byteBuffer.flip();
                //empty data solution
                if (!byteBuffer.hasRemaining()) {
                    //deal disconnection
                    out.println("disconnect with " + client.getRemoteAddress());
                    for (String k:SocketchannelMap.keySet()){
                        if(SocketchannelMap.get(k) == client){
                            SocketchannelMap.remove(k);
                        }
                    }
                    client.close();
                    key.cancel();
                    break;
                }
                while (byteBuffer.hasRemaining()) {
                    stringBuffer.append((char) byteBuffer.get());
                }
                //structWrong
                if(stringBuffer.toString().split("@").length < 2) {
                    client.write(ByteBuffer.wrap(("unknown@" +stringBuffer.toString()+"@invalid").getBytes()));
                    key.interestOps(SelectionKey.OP_READ);
                    break;
                }
                //fakeLink
                String accountID = stringBuffer.toString().split("@")[0];
                if(!loginRegisterDetect(stringBuffer.toString(), client)){
                    if(!client.equals(SocketchannelMap.get(accountID))){
                        client.write(ByteBuffer.wrap((accountID + "@"+ stringBuffer.toString().split("@")[1] + "@notLogin").getBytes()));
                        break;
                    }
                }

                key.interestOps(SelectionKey.OP_WRITE);
                commendBuffer.add(stringBuffer.toString());
                showCommandBuffer();
                break;

            case 3:
                //command process
                String data = sendBuffer.poll();
                String[] dataSet = data.split("@");
                out.println("Pre:" + data);
                //byteBuffer Init and put
                byteBuffer.put(data.getBytes());
                byteBuffer.flip();
                //login register
                if (dataSet[1].equals("login") | dataSet[1].equals("register")) {
                    client = loginRegisterResultServer(data);
                    client.write(byteBuffer);
                } else {
                    //Common Command
                    client = SocketchannelMap.get(dataSet[0]);
                    client.write(byteBuffer);
                }
                out.println("SEND:" + data);
                key.interestOps(SelectionKey.OP_READ);
                break;
        }

    }

    private boolean loginRegisterDetect(String command, SocketChannel channel) {
        String[] temp = command.split("@");
        if (Objects.equals(temp[1], "login") | Objects.equals(temp[1], "register")) {
            loginBuffer.put(temp[0], channel);
            return true;
        }
        return false;
    }

    private SocketChannel loginRegisterResultServer(String command) {
        String[] temp = command.split("@");
        SocketChannel tempSocket = loginBuffer.remove(temp[0]);
        if (temp[1].equals("register"))
            return tempSocket;
        if (temp[temp.length - 1].equals("True") ) {
            SocketchannelMap.put(temp[0], tempSocket);
            out.println("new login");
        } else {
            out.println("fail login");
        }
        return tempSocket;
    }

    private int keyToInt(SelectionKey key) {
        if (key.isAcceptable()) return 0;
        if (key.isConnectable()) return 1;
        if (key.isReadable()) return 2;
        if (key.isWritable()) return 3;
        return -1;
    }

}
