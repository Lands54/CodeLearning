package Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLite {
    Connection db;
    Statement stmt;

    void createDB(String database) throws SQLException {
        db = DriverManager.getConnection("jdbc:sqlite:" + database + ".db");
    }

    void setForeignKey(boolean mod) throws SQLException {
        stmt.executeUpdate("PRAGMA foreign_keys = " + (mod ? "ON;" : "OFF;"));
    }

    void setStmt() throws SQLException {
        this.stmt = db.createStatement();
    }

    void createTable(String table, String[] Value) throws SQLException {
        StringBuffer command = new StringBuffer("CREATE TABLE " + table);
        command.append('(');
        for (String i : Value) {
            command.append(i);
        }
        command.append(");");
        stmt.executeUpdate(command.toString());
    }

    void insertDate(String table, String attribute, String[] Value) throws SQLException {
        StringBuffer command = new StringBuffer("INSERT INTO " + table + "(" + attribute + ") " + "VALUES (");
        for (String value : Value) {
            command.append(value);
            command.append("),");
        }
        command.deleteCharAt(command.length() - 1);
        command.append(";");
        stmt.executeUpdate(command.toString());
    }

    public void write(String data) throws SQLException {
        stmt.executeUpdate(data);
    }

}
