//package Client;
//import javax.swing.*;
//import java.awt.*;
//
//import static java.lang.Thread.sleep;
//
//public class Awt {
//
//    public static void main(String[] args) throws InterruptedException {
//        JFrame temp = new JFrame("test");
//        temp.setLayout(null);
//        temp.setSize(3, 9);
//        temp.setLocation(300, 400);
//
//
//        for(int i = 0 ; i< 3 ;i++){
//            for(int j = 0; j<3;j++){
//                JButton jButton = new JButton(String.valueOf(3*j + i));
//                jButton.setBounds(50 + 100 * i,50 + 100 * j,100,100);
//                jButton.setMnemonic('r');
//                jButton.setToolTipText("112233");
//                temp.add(jButton);
//            }
//
//        }
//
//
//
//        temp.
//        temp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        temp.pack();
//        temp.setVisible(true);
//
//    }
//
//}
