package Client;

public class Tset implements Runnable{

    @Override
    public void run() {
        while (true){
            User user = Client.open(9999);
            user.login("1", "1");
            Client.clientDecoder.commandHandle("watchQuestion", "1");
        }
    }

    public static void main(String[] args) {
        Thread[] threads = new Thread[1000];
        for(int i = 0; i<5;i++){
            threads[i] = new Thread(new Tset());
            threads[i].start();
        }

    }
}
