abstract class Person implements Action{
    static int like = 0;
    static int comment = 0;

    @Override
    public void like() {
        //pass
    }
    @Override
    public void comment(){
        //pass
    }
}
