public class Student extends Person implements StudentAction{
    @Override
    public void ask() {
        //pass
    }

    public void setScore(){
        //pass
    }
}
