public class Teacher extends Person implements TeacherAction {
    @Override
    public void answer() {
        //pass
    }

    public void setScore(){
        //pass
    }
}
