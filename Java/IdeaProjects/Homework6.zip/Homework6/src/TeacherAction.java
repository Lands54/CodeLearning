public interface TeacherAction{
    void answer();
}
