public interface Action {
    public void like();
    public void comment();
}
