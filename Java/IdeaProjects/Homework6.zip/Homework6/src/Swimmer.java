public class Swimmer extends Person{
}
