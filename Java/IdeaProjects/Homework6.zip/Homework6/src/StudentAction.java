public interface StudentAction {
    void ask();
}
