//yqn
package org.example.ServerBlock;

public class Swimer extends Person {
    //can be objected Server.Server.Person
}
