public class NoSuchQuestion extends Exception{
    @Override
    public String getMessage() {
        return super.getMessage();
    }
    public void solution(){
        System.out.println("NoSuchQuestion, Question solved");
    }
}
