public class NoSuchUser extends Exception{
    public void solution(){
        System.out.println("NoSuchUser, Exception solved");
    }
}
