package org.example.ClientBlock;

public class User implements CommenUserAction {
    String accountID;
    String userName;
    String identity;
    String gender;
    String birthday;
    Question nowQuestion;
    Answer[] nowAnswerList;
    public boolean register(String accountID, String password){
        this.accountID = accountID;
        String[] temp = Client.clientDecoder.commandHandle("register", accountID + "@" + password);
        if(temp[2].equals("True")) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean login(String accountID, String password){
        this.accountID = accountID;
        String[] temp = Client.clientDecoder.commandHandle("login", accountID + "@" + password);
        if(temp[2].equals("True")) {
            this.watchSelfInformation();
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public void firstInformation(String userName, String identity, String birthday, String gender) {
        String[] temp = Client.clientDecoder.commandHandle("firstInformation", userName + "@" + identity + "@" + birthday + "@" + gender);
        this.userName = userName;
        this.identity = identity;
        this.birthday = birthday;
        this.gender = gender;
    }

    @Override
    public void changeUserName(String username) {
        String[] temp = Client.clientDecoder.commandHandle("changeUserName", "'" + username + "'");
        this.userName = temp[2].split("'")[1];
    }

    @Override
    public void changeIdentity(String identity) {
        String[] temp = Client.clientDecoder.commandHandle("changeIdentity", "'" + identity + "'");
        this.identity = temp[2].split("'")[1];
    }

    @Override
    public void changeBirthday(String birthday) {
        String[] temp = Client.clientDecoder.commandHandle("changeBirthday", "'" + birthday + "'");
        this.birthday = temp[2].split("'")[1];
    }

    @Override
    public void changeGender(String gender) {
        String[] temp = Client.clientDecoder.commandHandle("changeGender", "'" + gender + "'");
        this.gender = temp[2].split("'")[1];
    }

    @Override
    public void watchQuestionPage(String pageStart, String onePageNumber) {
        QuestionList.getList(Integer.parseInt(pageStart), Integer.parseInt(onePageNumber));
    }

    @Override
    public void watchQuestion(String questionID) {
        nowQuestion = QuestionList.get(Integer.parseInt(questionID));
    }

    @Override
    public void like(String answerID) {
        String[] temp = Client.clientDecoder.commandHandle("like", answerID);
    }

    @Override
    public void watchSelfInformation() {
        String[] temp = Client.clientDecoder.commandHandle("watchSelfInformation", "");
        this.userName = temp[2];
        this.identity = temp[3];
        this.birthday = temp[4];
        this.gender = temp[5];
    }

    public static void main(String[] args) {
        User user = Client.open("127.0.0.1", 9999);
        user.register("1", "1");
        user.login("1", "1");
    }

}
